var doc_api =
[
    [ "Functions", "doc_api_functions.html", [
      [ "Principal functions", "doc_api_functions.html#doc_api_funcs_1", null ],
      [ "Multithread support", "doc_api_functions.html#doc_api_funcs_2", null ],
      [ "Custom memory management", "doc_api_functions.html#doc_api_funcs_3", null ],
      [ "Auxiliary functions", "doc_api_functions.html#doc_api_funcs_4", null ]
    ] ],
    [ "Interfaces", "doc_api_interfaces.html", [
      [ "Principal interfaces", "doc_api_interfaces.html#doc_api_intf_1", null ],
      [ "Secondary interfaces", "doc_api_interfaces.html#doc_api_intf_2", null ],
      [ "Auxiliary interfaces", "doc_api_interfaces.html#doc_api_intf_3", null ]
    ] ]
];
var annotated =
[
    [ "asIBinaryStream", "classas_i_binary_stream.html", "classas_i_binary_stream" ],
    [ "asIJITCompiler", "classas_i_j_i_t_compiler.html", "classas_i_j_i_t_compiler" ],
    [ "asILockableSharedBool", "classas_i_lockable_shared_bool.html", "classas_i_lockable_shared_bool" ],
    [ "asIScriptContext", "classas_i_script_context.html", "classas_i_script_context" ],
    [ "asIScriptEngine", "classas_i_script_engine.html", "classas_i_script_engine" ],
    [ "asIScriptFunction", "classas_i_script_function.html", "classas_i_script_function" ],
    [ "asIScriptGeneric", "classas_i_script_generic.html", "classas_i_script_generic" ],
    [ "asIScriptModule", "classas_i_script_module.html", "classas_i_script_module" ],
    [ "asIScriptObject", "classas_i_script_object.html", "classas_i_script_object" ],
    [ "asIThreadManager", "classas_i_thread_manager.html", null ],
    [ "asITypeInfo", "classas_i_type_info.html", "classas_i_type_info" ],
    [ "asSBCInfo", "structas_s_b_c_info.html", "structas_s_b_c_info" ],
    [ "asSFuncPtr", "structas_s_func_ptr.html", null ],
    [ "asSMessageInfo", "structas_s_message_info.html", "structas_s_message_info" ],
    [ "asSVMRegisters", "structas_s_v_m_registers.html", "structas_s_v_m_registers" ]
];
var searchData=
[
  ['notifygarbagecollectorofnewobject',['NotifyGarbageCollectorOfNewObject',['../classas_i_script_engine.html#a52a7644b48cbc771e33db5070814f6df',1,'asIScriptEngine']]]
];

var searchData=
[
  ['helper_20functions',['Helper functions',['../doc_addon_helpers.html',1,'doc_addon_application']]],
  ['how_20to_20build_20a_20jit_20compiler',['How to build a JIT compiler',['../doc_adv_jit.html',1,'doc_adv_jit_topic']]]
];
